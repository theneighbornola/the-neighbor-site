(function () {
  var DOMAIN = 'the-neighbor-2.myshopify.com';
  var TOKEN = 'b8daa184a2d59de27b3fb299b9a5c882';
  var URL = 'https://' + DOMAIN + '/api/2024-10/graphql.json';
  function gql(query, variables) {
    return fetch(URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Shopify-Storefront-Access-Token': TOKEN },
      body: JSON.stringify({ query: query, variables: variables || {} })
    }).then(function (r) { return r.json(); });
  }
  var norm = function (s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, ' ').trim(); };
  var Q = 'query($c:String){products(first:250,after:$c){pageInfo{hasNextPage endCursor}nodes{title availableForSale variants(first:100){nodes{id title availableForSale QTY price{amount} selectedOptions{name value}}}}}}';
  function loadAll(withQty) {
    var out = [];
    function page(c) {
      return gql(Q.replace('QTY', withQty ? 'quantityAvailable' : ''), { c: c }).then(function (j) {
        if (j.errors) throw j.errors;
        var p = j.data.products; out = out.concat(p.nodes);
        return p.pageInfo.hasNextPage ? page(p.pageInfo.endCursor) : out;
      });
    }
    return page(null);
  }
  function load() {
    return loadAll(true).catch(function () { return loadAll(false); });
  }
  // Site product (or "Product::Color") -> exact Shopify product title. Edit here when names change.
  var MAP = {
   "Splatter Pitcher": "Splatter Pitcher",
   "Egg Cup": "Melrose Egg Cup",
   "Blue Feather Bowl::Small": "Medium Feather Bowl",
   "Blue Feather Bowl::Large": "Large Feather Bowl",
   "Enamel Oval Plate": "Enamel Oval Plate",
   "Mini Enamel Tumbler::White with Blue": "Mini Tumbler - White / Blue",
   "Mini Enamel Tumbler::Oyster Gray": "Mini Tumbler - Grey",
   "Mini Enamel Tumbler::Mustard Yellow": "Mini Tumbler - Yellow",
   "Year & Day Mugs::Moon": "Year & Day Mugs - Moon",
   "Year & Day Mugs::Canyon": "Year & Day Mugs - Canyon",
   "Blue Block Print Napkins": "Ichcha Blue Block Print Napkins",
   "Fern Brown Organic Cotton Napkins": "Icha Fern Napkins",
   "Golden Rays Napkins": "Ichcha Golden Ray Napkins",
   "Hand Block Print Cotton Table Napkins": "Ichcha Hand Block Print Napkins",
   "Hope Napkins": "Ichcha Hope Napkins",
   "Squiggle Tray": "Sophie Lou Jacobsen - Squiggle Tray",
   "Fruit Bowl": "Sophie Lou Jacobsen - Fruit Bowl",
   "Squiggle Pitcher": "Sophie Lou Jacobsen - Squiggle Pitcher",
   "Spiral Coasters": "Sophie Lou Jacobsen - Spiral Coasters",
   "Cosmo Coupe": "Sophie Lou Jacobsen - Cosmo Coupe",
   "Angel Flute Set": "Sophie Lou Jacobsen - Angel Flute, Clear",
   "Le Petit Verre Set": "Sophie Lou Jacobsen - Le Verre Petit",
   "Single Stem Spiral Candleholder": "Sophie Lou Jacobsen - Spiral Candleholder",
   "Speckle Grid Mug with Lid": "Speckle Grid Mug with Lid",
   "Simple Seeded Glassware": "SIMPLE SEEDED GLASSWARE - STEMMED - SET OF 4, OLIVE",
   "White Wine Glass": "White Wine Glass Dark Brown",
   "Red Wine Glass": "Red Wine Glass Dark Brown",
   "Green Pot Holder": "Pot Holder - Green",
   "Essential Floor Mat": "ESSENTIAL FLOOR MAT",
   "Record / Book Stand::Silver": "Upton Record Holder - Silver",
   "Record / Book Stand::Rose": "Upton Record Holder (Red)",
   "Acacia Wood Chess Set": "Sagebrook Home Chess Set",
   "Blossom Block Print Quilt::Full/Queen": "Blossom Block Print Quilt - QUEEN",
   "Blossom Block Print Quilt::King": "Blossom Block Print Quilt - KING",
   "Channel Grid Velvet Quilt::Full/Queen": "Channel Grid Velvet Quilt - QUEEN",
   "Channel Grid Velvet Quilt::King": "Channel Grid Velvet Quilt - KING",
   "Cut Out Bird Print Pillow Cover": "Toast - Bird Pillow",
   "Lattice Cloth Pillow Cover": "Toast Pillow Cover - Lattice",
   "Lattice Cloth Throw": "Toast Blanket",
   "Simple Linen Pillow::Olive": "SIMPLE LINEN PILLOW - OLIVE",
   "Simple Linen Pillow::Rust": "SIMPLE LINEN PILLOW - RUST",
   "Simple Linen Pillow::Peacock": "SIMPLE LINEN PILLOW - PEACOCK",
   "Wooden Spatula": "Wooden Spatula",
   "Walnut Wooden Oval Spoon": "Wooden Spoon",
   "Walnut Wooden Slotted Spoon": "Wooden Slotted Spoon",
   "Enamel Utensil Pot": "Falcon Utensil Pot",
   "Beech Wood Snack Bowl": "Wooden Bowls",
   "Wonder Valley Olive Oil": "Wonder Valley Olive Oil",
   "Wonder Valley Two Deserts Soap": "Wonder Valley Two Deserts Soap",
   "Wonder Valley Wild Garden Hand Wash": "Wonder Valley Hand Wash",
   "Enamel Soap Dish": "Enamel Soap Dish",
   "Cairn Cutting Boards": "Cairn Cutting Boards - Set of 3",
   "Simple Measuring Cups": "SIMPLE MEASURING CUPS - SILVER",
   "Simple Measuring Spoons": "SIMPLE MEASURING SPOONS - SILVER",
   "Simple Waffle Slippers::Bronze": "SIMPLE WAFFLE SLIPPERS - BRONZE",
   "Simple Waffle Slippers::Sage": "SIMPLE WAFFLE SLIPPERS - SAGE",
   "Woven Tray": "WOVEN TRAY",
   "Lurex Sponges::Pink / Terracotta / Gold": "LUREX SPONGES - SET OF 3",
   "Lurex Sponges::Blue / Green / Silver": "Kitchen Sponges - Set of 3 (blue/green)",
   "Happy Birthday No. 54 Card::Chartreuse": "Happy Birthday Card -  Chartreuse",
   "Happy Birthday No. 54 Card::Mauve": "Happy Birthday Card - Mauve",
   "Happy Birthday No. 54 Card::Sand": "Happy Birthday Card - Sand",
   "Artist's Marbled Gilded Journal": "Marbled Notebooks",
   "Linen Notebook": "Linen Notebooks",
   "Martin Serving Tray": "Martin Serving Tray",
   "Lucia Tea Spoons": "Spiral Tea Spoons",
   "Éclat Flatware": "Eclat Flatware - Set",
   "Cala Napkin Holder Set": "Cala Napkin Holder",
   "Marlo Serving Tongs": "Marlo Serving Tongs",
   "Calabria Serving Spoon": "Calabria Serving Spoon",
   "Nara Cheese Knife Set": "Nara Cheese Knife Set",
   "Graza Olive Tray": "Graza Olive Tray",
   "Aurelia Tray": "Aurelia Tray",
   "Cleo Dish::Red Marble": "Cleo Dish - Red",
   "Cleo Dish::Brown Marble": "Cleo Dish - Brown",
   "Cleo Dish::Forest Marble": "Cleo Dish - Forest",
   "Cleo Dish::Carrera Marble": "Cleo Dish - White",
   "Lune Tea Spoons": "Tea Spoons - Gems",
   "Isa Tray": "Isa Tray",
   "Mare Caviar Spoon Set": "Caviar Spoons",
   "Noa Candlestick Holder": "Noa Candlestick Holder",
   "Elio Table Lamp": "Elio Table Lamp",
   "Copa Tray": "Copa Tray",
   "Thin Taper Candles::Olive Green": "BRITISH COLOUR STANDARD - Thin Taper Candles - Olive Green",
   "Thin Taper Candles::Orchid Pink": "BRITISH COLOUR STANDARD - Thin Taper Candles - Orchid Pink",
   "Thin Taper Candles::Rainbow": "BRITISH COLOUR STANDARD - Thin Taper Candles - Rainbow",
   "The Photographer's Cookbook": "Coffee Table Book - The Photographers Cookbook",
   "Agnes Martin": "Coffee Table Book - Agnes",
   "Joan Didion: What She Means": "Coffee Table Book - Joan Didion",
   "Josef Albers in Mexico": "Coffee Table Book - Josef Albets in Mexico",
   "Sam Falls: Plein Air": "Coffee Table Book - Plein Air",
   "Wes Anderson: The Archives": "Coffee Table Book - Wes Anderson",
   "Justine Kurland: Girl Pictures": "Coffee Table Book - Girl Pictures",
   "Lee Friedlander: Life Still": "Coffee Table Book - Life Still",
   "Richard Misrach: Destroy This Memory": "Destroy this Memory Coffee Table Book",
   "Handcrafted French Florist Candles": "French Florist Candles (packs of 10)",
   "Handcrafted French Stick Candles": "French Stick Candles (pack of 3)",
   "Dinner Candles::Green": "Pack of Candles - Green",
   "Dinner Candles::Brown": "Pack of Candles - Brown",
   "Dinner Candles::Red": "Pack of Candles - Red",
   "Dinner Candles::Blue": "Pack of Candles - Blue",
   "Nosedive Candle::Amber Hour": "Nosedive Candle - Amber Hour",
   "Nosedive Candle::Nightcap": "Nosedive - Candle Nightcap",
   "Nosedive Candle::Sunburnt": "Nosedive Candle - Sunburnt",
   "Nosedive Candle::The Daily": "Nosedive Candle - The Daily",
   "Hazeltine Candle::Oasis": "OASIS SCENTED CANDLE",
   "Hazeltine Candle::Pasadena": "PASADENA SCENTED CANDLE",
   "Rodi Glass": "Rodi Glass Framboise",
   "Expresso Soucoupe": "Espresso Cups",
   "Bath Robe": "Bath Robe",
   "Bath Milk": "BAINA - Bath Milk",
   "Body Scrub": "BAINA - Body Scrub",
   "Post-Bathe Oil": "BAINA - Post Bathe Oil",
   "Hand Wash": "BAINA - Hand Wash",
   "Busby Pool Towel::Fuyu & Chalk": "BUSBY POOL TOWEL fuyu & chalk",
   "Busby Pool Towel::Caper & Chalk": "BUSBY POOL TOWEL caper & chalk",
   "Franklin Bath Towel::Fuyu & Chalk": "FRANKLIN BATH TOWEL fuyu & chalk",
   "Franklin Bath Towel::Caper & Chalk": "FRANKLIN BATH TOWEL caper & chalk",
   "Sorn Bath Towel": "SORN BATH TOWEL celeste & chalk",
   "Echo Bath Mat::Fuyu & Chalk": "ECHO BATH MAT fuyu & chalk",
   "Echo Bath Mat::Caper & Chalk": "Shop All / ECHO BATH MAT caper & chalk",
   "Devon Bath Mat": "DEVON BATH MAT celeste & chalk",
   "Ness Hand Towel": "BAINA - Hand Towel (Celeste & Chalk)",
   "San Luis Hand Towel::Fuyu & Chalk": "SAN LUIS HAND TOWEL fuyu & chalk",
   "San Luis Hand Towel::Caper & Chalk": "SAN LUIS HAND TOWEL caper & chalk",
   "Quill Face Cloth::Paloma Sun & Ecru": "BAINA - Face Cloth Gift Set (Red)",
   "Quill Face Cloth::Sage & Chalk": "BAINA - Face Towel Gift Set (Sage & Chalk)",
   "Quill Face Cloth::Tabac & Noir": "BAINA Face Towel Gift Set (Brown)",
   "Quill Face Cloth::Cement & Rhus": "BAINA - Face Cloth Gift Set (Blue/Brown)"
  };
  function apply(list, shop) {
    var byTitle = {};
    shop.forEach(function (sp) { byTitle[norm(sp.title)] = sp; });
    var find = function (k) { return MAP[k] ? byTitle[norm(MAP[k])] : byTitle[norm(k.split('::')[0])]; };
    var vOk = function (v) { return v.availableForSale && (v.quantityAvailable == null || v.quantityAvailable > 0); };
    var pickVar = function (sp, label) {
      var vs = sp.variants.nodes; if (vs.length === 1 || !label) return vs[0];
      var n = norm(label);
      return vs.find(function (v) { return norm(v.title) === n || v.selectedOptions.some(function (o) { return norm(o.value) === n; }); }) || null;
    };
    var missing = [];
    list.forEach(function (p) {
      if (p.colors && p.colors.length) {
        p.colors.forEach(function (c) {
          var sp = find(p.name + '::' + c.name) || find(p.name);
          var v = sp && pickVar(sp, MAP[p.name + '::' + c.name] ? null : c.name);
          c.variantId = v ? v.id : null;
          if (v) c.soldOut = !vOk(v); else missing.push(p.name + ' / ' + c.name);
        });
        p.soldOut = p.colors.every(function (c) { return c.soldOut; });
      } else {
        var sp = find(p.name), v = sp && sp.variants.nodes[0];
        p.variantId = v ? v.id : null;
        if (v) p.soldOut = !vOk(v); else missing.push(p.name);
      }
    });
    if (missing.length) console.info('[Shopify] Not linked to a Shopify product:', missing);
    return missing;
  }
  // Cart permalink: opens Shopify checkout directly with these items.
  function checkout(lines) {
    var parts = lines.map(function (x) { return String(x.id).split('/').pop() + ':' + x.qty; });
    return Promise.resolve('https://' + DOMAIN + '/cart/' + parts.join(','));
  }
  window.N4Shopify = { load: load, apply: apply, checkout: checkout };
})();
